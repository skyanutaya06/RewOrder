import 'package:flutter/material.dart';
import 'package:flutterss/login_page.dart';

class Register extends StatelessWidget {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();

  Register({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Register'),
      ),
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/image/paper.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Register',
                style: TextStyle(
                  fontSize: 24.0,
                  color: Color.fromARGB(255, 0, 0, 0),
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 20.0),
              Container(
                constraints: const BoxConstraints(
                  maxWidth: 350.0,
                ),
                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 5.0),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Form(
                  key: _formKey,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  child: Column(
                    children: [
                      TextFormField(
                        controller: _emailController,
                        decoration: const InputDecoration(
                          labelText: 'อีเมล',
                          labelStyle: TextStyle(
                            color: Color.fromARGB(255, 0, 0, 0),
                          ),
                        ),
                        validator: (value) {
                          if (value?.isEmpty ?? true) {
                            return 'กรุณากรอกอีเมล';
                          }
                          if (isValidEmail(value!)) {
                            return 'รูปแบบอีเมลไม่ถูกต้อง';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 20.0),
                      TextFormField(
                        controller: _usernameController, // เพิ่ม Controller สำหรับชื่อผู้ใช้
                        decoration: const InputDecoration(
                          labelText: 'ชื่อผู้ใช้',
                          labelStyle: TextStyle(
                            color: Color.fromARGB(255, 0, 0, 0),
                          ),
                        ),
                        validator: (value) {
                          if (value?.isEmpty ?? true) {
                            return 'กรุณากรอกชื่อผู้ใช้';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 20.0),
                      TextFormField(
                        controller: _passwordController,
                        decoration: const InputDecoration(
                          labelText: 'รหัสผ่าน',
                          labelStyle: TextStyle(
                            color: Color.fromARGB(255, 0, 0, 0),
                          ),
                        ),
                        obscureText: true,
                        validator: (value) {
                          if (value?.isEmpty ?? true) {
                            return 'กรุณากรอกรหัสผ่าน';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 20.0),
                      TextFormField(
                        controller: _confirmPasswordController,
                        decoration: const InputDecoration(
                          labelText: 'ยืนยันรหัสผ่าน',
                          labelStyle: TextStyle(
                            color: Color.fromARGB(255, 0, 0, 0),
                          ),
                        ),
                        obscureText: true,
                        validator: (value) {
                          if (value?.isEmpty ?? true) {
                            return 'กรุณายืนยันรหัสผ่าน';
                          }
                          if (value != _passwordController.text) {
                            return 'รหัสผ่านไม่ตรงกัน';
                          }
                          return null;
                        },
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 25.0),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
  if (_passwordController.text != _confirmPasswordController.text) {
    _showPasswordMismatchDialog(context);
  } else {
    // รหัสผ่านและการยืนยันรหัสผ่านตรงกัน
    // ทำตามขั้นตอนการลงทะเบียนต่อไป
    final email = _emailController.text;
    final username = _usernameController.text;

    // ส่งอีเมลแจ้งยืนยัน และเพิ่มข้อมูลผู้ใช้ใน Firebase Realtime Database
    sendEmailConfirmation(email, username);

    // แสดง SnackBar แจ้งเตือนลงทะเบียนสำเร็จ
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('ลงทะเบียนสำเร็จ'),
        backgroundColor: Colors.green,
      ),
    );

    // ย้ายไปยังหน้า "เข้าสู่ระบบ" หลังจากลงทะเบียน
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (context) => LoginPage(),
      ),
    );
  }
}
                },
                style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(
                    const Color.fromARGB(255, 15, 49, 141),
                  ),
                  foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                  minimumSize: MaterialStateProperty.all<Size>(
                    const Size(150, 50),
                  ),
                ),
                child: const Text(
                  'ลงทะเบียน',
                  style: TextStyle(fontSize: 17),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
bool isValidEmail(String email) {
    final emailPattern =
        RegExp(r'^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$');
    return emailPattern.hasMatch(email);
  }

  void _showPasswordMismatchDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('ข้อผิดพลาด'),
          content: const Text('รหัสผ่านและการยืนยันรหัสผ่านไม่ตรงกัน'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('ปิด'),
            ),
          ],
        );
      },
    );
  }

  void sendEmailConfirmation(String emailAddress, String username) async {
    // ส่งอีเมลยืนยันไปที่อีเมลผู้ใช้และเพิ่มข้อมูลผู้ใช้ใน Firebase Realtime Database
    // คุณต้องเปลี่ยนส่วนนี้เพื่อใช้งาน Firebase Authentication และ Firebase Realtime Database ของคุณ
  }
}