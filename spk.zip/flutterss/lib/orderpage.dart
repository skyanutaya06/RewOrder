import 'package:flutter/material.dart';
import 'package:flutterss/menu.dart';
import 'package:flutterss/newpage.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';

class OrderPage extends StatefulWidget {
  final List<Order> ordersToOrder;

  const OrderPage(this.ordersToOrder);

  @override
  _OrderPageState createState() => _OrderPageState();
}

class _OrderPageState extends State<OrderPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('หน้าสั่งสินค้า'),
        actions: const [
          ThreeDotsMenu(),
        ],
      ),
      body: ListView.builder(
        itemCount: widget.ordersToOrder.length,
        itemBuilder: (context, index) {
          return Card(
            elevation: 3,
            margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            color: Colors.white.withOpacity(0.8),
            child: ListTile(
              title: Text(
                'ชื่อสินค้า: ${widget.ordersToOrder[index].productName}',
              ),
              subtitle: Text(
                'จำนวนที่ต้องสั่ง: ${widget.ordersToOrder[index].maxQuantity}',
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          _printData();
        },
        child: const Icon(Icons.print),
      ),
    );
  }

  void _printData() {
    final doc = pw.Document();

    doc.addPage(
      pw.Page(
        build: (pw.Context context) {
          return pw.Column(
            children: widget.ordersToOrder.map((order) {
              return pw.Row(
                children: [
                  pw.Text('ชื่อสินค้า: ${order.productName}'),
                  pw.Text('จำนวนที่ต้องสั่ง: ${order.maxQuantity}'),
                ],
              );
            }).toList(),
          );
        },
      ),
    );

    Printing.layoutPdf(
      onLayout: (PdfPageFormat format) async {
        return doc.save();
      },
    );
  }
}
