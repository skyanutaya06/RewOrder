import 'package:flutter/material.dart';
import 'package:flutterss/forgot_password.dart';
import 'package:flutterss/main.dart';
import 'package:flutterss/register.dart';

bool loginSuccessful = false;
bool isUserRegistered() {
  // ตรวจสอบว่าผู้ใช้ลงทะเบียนแล้ว โดยใช้ข้อมูลจาก Firebase Authentication หรือฐานข้อมูลของคุณ
  // คืนค่า true ถ้าผู้ใช้ลงทะเบียนแล้ว และคืนค่า false ถ้ายังไม่ได้ลงทะเบียน
  // คุณต้องปรับแก้ฟังก์ชันนี้ตามวิธีการทำงานของระบบลงทะเบียนของคุณ
  return true; // เพียงตัวอย่าง ควรตรวจสอบจากระบบจริง
}

class LoginPage extends StatelessWidget {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  LoginPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login'),
      ),
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/image/paper.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'Login',
                style: TextStyle(
                  fontSize: 24.0,
                  color: Color.fromARGB(255, 0, 0, 0),
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 20.0),
              Container(
                constraints: const BoxConstraints(
                  maxWidth: 350.0,
                ),
                padding:
                    const EdgeInsets.symmetric(horizontal: 16.0, vertical: 5.0),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      TextFormField(
                        decoration: const InputDecoration(
                          labelText: 'ชื่อผู้ใช้',
                          labelStyle: TextStyle(
                            color: Color.fromARGB(255, 0, 0, 0),
                          ),
                        ),
                        validator: (value) {
                          if (value?.isEmpty ?? true) {
                            return 'กรุณากรอกชื่อผู้ใช้';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 20.0),
                      TextFormField(
                        obscureText: true,
                        decoration: const InputDecoration(
                          labelText: 'รหัสผ่าน',
                          labelStyle: TextStyle(
                            color: Color.fromARGB(255, 0, 0, 0),
                          ),
                        ),
                        validator: (value) {
                          if (value?.isEmpty ?? true) {
                            return 'กรุณากรอกรหัสผ่าน';
                          }
                          return null;
                        },
                      ),
                      const SizedBox(height: 20.0),
                      ElevatedButton(
  onPressed: () {
    if (_formKey.currentState!.validate()) {
      if (isUserRegistered()) {
        const snackBar = SnackBar(
          content: Text('เข้าสู่ระบบสำเร็จ'),
          backgroundColor: Colors.green,
        );
        ScaffoldMessenger.of(context).showSnackBar(snackBar);

        Navigator.of(context).pushReplacement(
          MaterialPageRoute(
            builder: (context) => const MyApp(),
          ),
        );
      } else {
        // แสดงข้อความว่าผู้ใช้ต้องลงทะเบียนก่อนเข้าสู่ระบบ
        // และเปิดหน้าลงทะเบียน
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('คุณต้องลงทะเบียนก่อนเข้าสู่ระบบ'),
            backgroundColor: Colors.red,
          ),
        );
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => Register(),
          ),
        );
      }
    }
  },

                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all<Color>(
                            const Color.fromARGB(255, 15, 49, 141),
                          ),
                          foregroundColor:
                              MaterialStateProperty.all<Color>(Colors.white),
                          minimumSize: MaterialStateProperty.all<Size>(
                            const Size(150, 50),
                          ),
                        ),
                        child: const Text(
                          'เข้าสู่ระบบ',
                          style: TextStyle(fontSize: 18),
                        ),
                      ),
                      const SizedBox(height: 10.0),
                      TextButton(
                        onPressed: () {
                          // เมื่อคลิกที่ปุ่มหรือลิงก์ "ลืมรหัสผ่าน"
                          // เรียก Navigator.push เพื่อเปิดหน้า "ลืมรหัสผ่าน"
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) => const ForgotPasswordPage(),
                            ),
                          );
                        },
                        child: const Text(
                          'ลืมรหัสผ่าน?',
                          style: TextStyle(
                            color: Color.fromARGB(255, 15, 49, 141),
                            fontSize: 16.0,
                          ),
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          // เมื่อคลิกที่ปุ่มหรือลิงก์ "ลงทะเบียน"
                          // เรียก Navigator.push เพื่อเปิดหน้า "ลงทะเบียน"
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (context) =>
                                  Register(), // แทนด้วยหน้าลงทะเบียนของคุณ
                            ),
                          );
                        },
                        child: const Text(
                          'ลงทะเบียน',
                          style: TextStyle(
                            color: Color.fromARGB(255, 15, 49, 141),
                            fontSize: 16.0,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
