import 'package:flutter/material.dart';
import 'package:flutterss/login_page.dart';

class ThreeDotsMenu extends StatelessWidget {
  const ThreeDotsMenu({Key? key});

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton(
      onSelected: (value) {
        if (value == 'login') {
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => LoginPage(),
            ),
          );  
        } else {
          // Handle other menu options here.
        }
      },
      itemBuilder: (BuildContext context) {
        return [
          const PopupMenuItem(
            value: 'login',
            child: Text('การเข้าสู่ระบบ'),
          ),
        ];
      },
      icon: const Icon(Icons.more_vert),
    );
  }
}

class UserRegistrationProvider extends ChangeNotifier {
  String? _registeredUsername;
  String? _registeredPassword;

  String? get registeredUsername => _registeredUsername;
  String? get registeredPassword => _registeredPassword;

  void registerUser(String username, String password) {
    _registeredUsername = username;
    _registeredPassword = password;
    notifyListeners();
  }
}
