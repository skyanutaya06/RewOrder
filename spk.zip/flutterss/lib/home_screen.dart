import 'package:flutter/material.dart';
import 'package:flutterss/menu.dart';
import 'package:flutterss/newpage.dart';
import 'package:flutterss/orderpage.dart';

class TestPage extends StatefulWidget {
  const TestPage({Key? key, Order? order}) : super(key: key);

  @override
  _TestPageState createState() => _TestPageState();
}

class _TestPageState extends State<TestPage> {
  List<Order> orders = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('คลังวัสดุชิ้นงาน'),
        actions: const [
          ThreeDotsMenu(),
        ],
      ),
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/image/paper.jpg'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          ListView.builder(
            itemCount: orders.length,
            itemBuilder: (context, index) {
              return Card(
                elevation: 3,
                margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                color: Colors.white.withOpacity(0.8),
                child: ListTile(
                  title: Text('ชื่อสินค้า: ${orders[index].productName}'),
                  subtitle: Text('ยอดคงเหลือ: ${orders[index].balance}'),
                  onTap: () {
                    _editBalance(orders[index]);
                  },
                ),
              );
            },
          ),
          Positioned(
            bottom: 16,
            left: 0,
            right: 0,
            child: Center(
              child: SizedBox(
                width: 100, // กำหนดความกว้างของปุ่มตามที่ต้องการ
                child: ElevatedButton(
                  onPressed: () {
                    _saveAllData();
                  },
                  child: const Text(
                    'บันทึก',
                    style: TextStyle(
                      fontSize: 17, // กำหนดขนาดตัวอักษรตามที่ต้องการ
                      color: Colors.white, // กำหนดสีของตัวอักษร
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final result = await Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => const AddOrderPage(),
            ),
          );

          if (result != null && result is Order) {
            setState(() {
              orders.add(result);
            });
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  void _editBalance(Order order) {
    showDialog(
      context: context,
      builder: (context) {
        final _balanceController = TextEditingController();
        _balanceController.text = order.balance.toString();
        return AlertDialog(
          title: const Text('แก้ไขยอดคงเหลือ'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('ชื่อสินค้า: ${order.productName}'),
              TextFormField(
                controller: _balanceController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'ยอดคงเหลือ'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'กรุณากรอกยอดคงเหลือ';
                  }
                  double balance = double.parse(value);
                  if (balance < 0 || balance > order.maxQuantity) {
                    return 'ยอดคงเหลือไม่ถูกต้อง';
                  }
                  return null;
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('ยกเลิก'),
            ),
            TextButton(
              onPressed: () {
                if (_balanceController.text.isNotEmpty) {
                  double balance = double.parse(_balanceController.text);
                  order.balance = balance;
                  Navigator.of(context).pop();

                  // อัปเดตหน้าให้แสดงยอดคงเหลือทันที
                  setState(() {});
                }
              },
              child: const Text('บันทึก'),
            ),
          ],
        );
      },
    );
  }

  void _saveAllData() {
    // คำนวณยอดที่ต้องสั่งจากยอดคงเหลือ < จำนวนน้อยสุด
    final List<Order> ordersToOrder =
        orders.where((order) => order.balance < order.minQuantity).toList();

    if (ordersToOrder.isNotEmpty) {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (context) => OrderPage(ordersToOrder),
        ),
      );
    }
  }
}
