import 'package:flutter/material.dart';

class ForgotPasswordPage extends StatelessWidget {
  const ForgotPasswordPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final TextEditingController usernameController = TextEditingController();
    final TextEditingController passwordController = TextEditingController();
    final TextEditingController confirmPasswordController =
        TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: const Text('ลืมรหัสผ่าน'),
      ),
      body: Container(
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/image/paper.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'ลืมรหัสผ่าน',
                style: TextStyle(
                  fontSize: 24.0,
                  color: Color.fromARGB(255, 0, 0, 0),
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 20.0),
              Container(
                constraints: const BoxConstraints(
                  maxWidth: 350.0,
                ),
                padding:
                    const EdgeInsets.symmetric(horizontal: 16.0, vertical: 5.0),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Column(
                  children: [
                    TextFormField(
                      controller: usernameController,
                      decoration: const InputDecoration(
                        labelText: 'ชื่อผู้ใช้ (หรืออีเมล)',
                        labelStyle: TextStyle(
                          color: Color.fromARGB(255, 0, 0, 0),
                        ),
                      ),
                      validator: (value) {
                        if (value?.isEmpty ?? true) {
                          return 'กรุณากรอกชื่อผู้ใช้';
                        }
                        return null; // ไม่มีข้อผิดพลาด
                      },
                    ),
                    const SizedBox(height: 10.0),
                    TextFormField(
                      controller: passwordController,
                      obscureText: true,
                      decoration: const InputDecoration(
                        labelText: 'รหัสผ่านใหม่',
                        labelStyle: TextStyle(
                          color: Color.fromARGB(255, 0, 0, 0),
                        ),
                      ),
                      validator: (value) {
                        if (value?.isEmpty ?? true) {
                          return 'กรุณากรอกชื่อผู้ใช้';
                        }
                        return null; // ไม่มีข้อผิดพลาด
                      },
                    ),
                    const SizedBox(height: 10.0),
                    TextFormField(
                      controller: confirmPasswordController,
                      obscureText: true,
                      decoration: const InputDecoration(
                        labelText: 'ยืนยันรหัสผ่าน',
                        labelStyle: TextStyle(
                          color: Color.fromARGB(255, 0, 0, 0),
                        ),
                      ),
                      validator: (value) {
                        if (value?.isEmpty ?? true) {
                          return 'กรุณากรอกชื่อผู้ใช้';
                        }
                        return null; // ไม่มีข้อผิดพลาด
                      },
                    ),
                    const SizedBox(height: 20.0),
                    ElevatedButton(
                      onPressed: () {
                        final String newPassword = passwordController.text;
                        final String confirmPassword =
                            confirmPasswordController.text;

                        if (newPassword.isNotEmpty &&
                            confirmPassword.isNotEmpty) {
                          if (newPassword == confirmPassword) {
                            // รหัสผ่านถูกต้อง ดำเนินการตามต้องการ

                            // หลังจากรีเซ็ตรหัสผ่านเรียบร้อย
                            // เรียก Navigator.pop(context) เพื่อกลับไปหน้า "เข้าสู่ระบบ"
                            Navigator.pop(context);

                            // แสดง SnackBar หรือแจ้งเตือนให้ผู้ใช้ทราบว่ารหัสผ่านได้รับการเปลี่ยนแล้ว
                            const snackBar = SnackBar(
                              content: Text('รหัสผ่านได้รับการเปลี่ยนแล้ว'),
                              backgroundColor: Colors.green,
                            );
                            ScaffoldMessenger.of(context)
                                .showSnackBar(snackBar);
                          } else {
                            // รหัสผ่านไม่ตรงกัน แสดงข้อความแจ้งเตือน
                            const snackBar = SnackBar(
                              content: Text('รหัสผ่านไม่ตรงกัน'),
                              backgroundColor: Colors.red,
                            );
                            ScaffoldMessenger.of(context)
                                .showSnackBar(snackBar);
                          }
                        } else {
                          // กรอกข้อมูลไม่ครบ แสดงข้อความแจ้งเตือน
                          const snackBar = SnackBar(
                            content: Text('กรุณากรอกข้อมูลให้ครบ'),
                            backgroundColor: Colors.red,
                          );
                          ScaffoldMessenger.of(context).showSnackBar(snackBar);
                        }
                      },
                      style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all<Color>(
                          const Color.fromARGB(255, 15, 49, 141),
                        ),
                        foregroundColor:
                            MaterialStateProperty.all<Color>(Colors.white),
                        minimumSize: MaterialStateProperty.all<Size>(
                          const Size(150, 50),
                        ),
                      ),
                      child: const Text(
                        'รีเซ็ตรหัสผ่าน',
                        style: TextStyle(fontSize: 18),
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

