import 'package:flutter/material.dart';

class Order {
  String productName;
  double maxQuantity;
  double minQuantity;
  String unit;
  double balance;

  Order({
    required this.productName,
    required this.maxQuantity,
    required this.minQuantity,
    required this.unit,
    required this.balance,
  });
}

class AddOrderPage extends StatefulWidget {
  const AddOrderPage({Key? key}) : super(key: key);

  @override
  _AddOrderPageState createState() => _AddOrderPageState();
}

class _AddOrderPageState extends State<AddOrderPage> {
  final _formKey = GlobalKey<FormState>();
  final _productNameController = TextEditingController();
  final _maxQuantityController = TextEditingController();
  final _minQuantityController = TextEditingController();
  String _selectedUnit = 'กิโลกรัม';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('เพิ่มคำสั่งซื้อ'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'รายละเอียดคำสั่งซื้อ:',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              TextFormField(
                controller: _productNameController,
                decoration: const InputDecoration(labelText: 'ชื่อสินค้า'),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'กรุณากรอกชื่อสินค้า';
                  }
                  return null;
                },
              ),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _maxQuantityController,
                      decoration: const InputDecoration(
                          labelText: 'จำนวนสูงสุดในการสั่งซื้อแต่ละรอบ'),
                      keyboardType: TextInputType.number,
                      validator: (value) {
                        if (value!.isEmpty) {
                          return 'กรุณากรอกจำนวนสูงสุดในการสั่งซื้อแต่ละรอบ';
                        }
                        if (double.tryParse(value) == null ||
                            double.parse(value) <= 0) {
                          return 'กรุณากรอกจำนวนที่มากกว่า 0';
                        }
                        return null;
                      },
                    ),
                  ),
                  
                ],
              ),
              TextFormField(
                controller: _minQuantityController,
                decoration: const InputDecoration(
                    labelText: 'จำนวนน้อยสุดของสินค้าในการสั่งซื้อแต่ละรอบ'),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'กรุณากรอกจำนวนน้อยสุดของสินค้าในการสั่งซื้อแต่ละรอบ';
                  }
                  if (double.tryParse(value) == null ||
                      double.parse(value) <= 0) {
                    return 'กรุณากรอกจำนวนที่มากกว่า 0';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    Order newOrder = Order(
                      productName: _productNameController.text,
                      maxQuantity: double.parse(_maxQuantityController.text),
                      minQuantity: double.parse(_minQuantityController.text),
                      unit: _selectedUnit,
                      balance: 0, // กำหนดยอดคงเหลือเริ่มต้นเป็น 0
                    );

                    Navigator.of(context).pop(newOrder);
                  }
                },
                child: const Text(
                  'เพิ่มคำสั่งซื้อ',
                  style: TextStyle(
                    fontSize: 17, // กำหนดขนาดตัวอักษรตามที่ต้องการ
                    color: Colors.white, // กำหนดสีของตัวอักษร
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
