package com.example.flutterss

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
